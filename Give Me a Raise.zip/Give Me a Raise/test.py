from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
import pyautogui
import time
import datetime
import random
import keyboard
import subprocess

service = Service(executable_path="chromedriver.exe")
driver = webdriver.Chrome(service=service)

driver.get("https://www.wendyswantstoknow.com/?AspxAutoDetectCookieSupport=1")
driver.maximize_window()

input_element = driver.find_element(By.ID, "InputStoreNum")
input_element.send_keys("4740" + Keys.ENTER)

time.sleep(1)

click_button = driver.find_element(By.CLASS_NAME, "ui-datepicker-trigger")
click_button.click()
time.sleep(0.25)

# Select today's date (Improved)
today = datetime.date.today()
day_element = driver.find_element(By.XPATH, f"//a[text()='{today.day}']")
day_element.click()

time.sleep(0.5)

current_time = datetime.datetime.now()
current_hour = current_time.hour
current_minute = current_time.minute

# Hour Selection
hour_dropdown = driver.find_element(By.ID, "InputHour")
hour_dropdown.click()
time.sleep(0.25)

for _ in range(current_hour):  # Press down arrow for each hour
    hour_dropdown.send_keys(Keys.ARROW_DOWN)
hour_dropdown.send_keys(Keys.ENTER)

time.sleep(0.25)

# Minute Selection
minute_dropdown = driver.find_element(By.ID, "InputMinute")
minute_dropdown.click()
time.sleep(0.25)

for _ in range(current_minute):
    minute_dropdown.send_keys(Keys.ARROW_DOWN)
minute_dropdown.send_keys(Keys.ENTER)

time.sleep(0.25)

# AM/PM Selection
meridian_dropdown = driver.find_element(By.ID, "InputMeridian")
meridian_dropdown.click()
time.sleep(0.25)

if current_time.hour >= 12:  # Select PM (down arrow twice)
    meridian_dropdown.send_keys(Keys.ARROW_DOWN)
    meridian_dropdown.send_keys(Keys.ARROW_DOWN)
else: #select AM (down arrow once)
    meridian_dropdown.send_keys(Keys.ARROW_DOWN)

meridian_dropdown.send_keys(Keys.ENTER)
time.sleep(0.5)
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()

time.sleep(0.5)
click_button = driver.find_element(By.CLASS_NAME, "Opt1")
click_button.click()

time.sleep(0.5)
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
dine_in_x = 505
dine_in_y = 583
carry_out_x = 505
carry_out_y = 624
# Randomly choose between dine_in and carry_out
if random.random() < 0.5:  # More concise 50/50 choice
    pyautogui.click(x=dine_in_x, y=dine_in_y)
else:
    pyautogui.click(x=carry_out_x, y=carry_out_y)

time.sleep(0.1)
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
click_button = driver.find_element(By.CLASS_NAME, "Opt5")
click_button.click()
time.sleep(0.1)
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
subprocess.run(['python', 'ZoomInModule.pyw'])
subprocess.run(['python', 'select text on screen1.pyw'])
subprocess.run(['python', 'ZoomOutModule.pyw'])
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(1)
elements = driver.find_elements(By.CLASS_NAME, "Opt5")
for element in elements:
    element.click()
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
click_button = driver.find_element(By.CLASS_NAME, "Opt2")
click_button.click()
time.sleep(0.5)
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
click_button = driver.find_element(By.CLASS_NAME, "Opt5")
click_button.click()
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
pyautogui.click(508, 401)
subprocess.run(['python', 'SubmitAwnsersModule.pyw'])
time.sleep(0.5)
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(0.5)
click_button = driver.find_element(By.CLASS_NAME, "Opt3")
click_button.click()
time.sleep(0.5)
subprocess.run(['python', 'ZoomInModule.pyw'])
subprocess.run(['python', 'select text on screen2.pyw'])
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
subprocess.run(['python', 'select text on screen3.pyw'])
subprocess.run(['python', 'ZoomOutModule.pyw'])
next_button = driver.find_element(By.ID, "NextButton")
next_button.click()
time.sleep(100000)
driver.quit()